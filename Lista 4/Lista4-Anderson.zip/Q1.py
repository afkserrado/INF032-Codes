'''
1.Faça um dicionário com as 5 pessoas mais perto de você, tendo o nome como chave e a cor da
camisa que está usando como valor.
'''

pessoas = {"Anderson": "marrom", "Luan": "rosa", "Diego": "preto", "Rafaela": "azul", "Daniela": "amarelo"}

print("Dicionario:", pessoas)
'''
4. Crie um dicionário d e coloque nele seus dados: nome, idade, telefone, endereço. Usando o
dicionário d criado anteriormente, imprima seu nome.
'''

d = {"nome": "Anderson Serrado", "idade": 29, "telefone": "(71) 98845-9482", "endereco": "Avenida Manoel Dias, 25, Amaralina"}

nome = d["nome"]

print("\n")
print("Dados:", d)
print("Nome s1:", d["nome"])
print("Nome s2:", d["nome"])
print("\n")
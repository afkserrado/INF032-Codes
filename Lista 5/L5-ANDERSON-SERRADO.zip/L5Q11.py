'''
11. Entrar com um número se ele for igual ou maior que 20, escrever "o número é igual ou maior que 20, se for menor "o número é menor que 20"
'''

numero = int(input("Informe um numero: "))

if numero >= 20:
    print("O número é igual ou maior que 20.")
else:
    print("O número é menor que 20.")
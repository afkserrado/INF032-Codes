'''
14.Entrar com um número e escrever se ele é ou não divisível por 5.
'''

num = int(input("Informe um numero: "))

if num % 5 == 0:
    print(f"O numero {num} e divisivel por 5.")
else:
    print(f"O numero {num} nao e divisivel por 5.")
